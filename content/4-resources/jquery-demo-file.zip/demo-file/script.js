$(document).ready(function(){
  
  /* rounding corners using a class */
  
  /*
  $('.cell').click(function(e) {
      $(this).addClass('round');
  });

  */
  
  /* making the background color colorful */
  
  /*
  $('body').click(function(e) {
      $(this).addClass('colorful');
  });
  */
  
  /* skewing the grid */

  /*
  $('.cell').hover(function() {
     $(this).addClass('skew');
  }, function() {
     $(this).removeClass('skew');
  });  
  */

});